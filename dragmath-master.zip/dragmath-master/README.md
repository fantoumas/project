dragmath
========

DragMath is a drag and drop equation editor in the form of a Java applet. Once an expression is created the user can convert it into a variety of different linear syntax for mathematics, including MathML, LaTeX, Maple, Maxima or any user defined style.

DragMath Website:    www.dragmath.bham.ac.uk
