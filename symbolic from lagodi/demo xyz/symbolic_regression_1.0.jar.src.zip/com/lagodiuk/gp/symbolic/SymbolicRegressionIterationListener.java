package com.lagodiuk.gp.symbolic;

public abstract interface SymbolicRegressionIterationListener
{
  public abstract void update(SymbolicRegressionEngine paramSymbolicRegressionEngine);
}


/* Location:              C:\Users\Christina\Desktop\Uni\Project\symbolic from lagodi\genetic-programming\symbolic_regression_1.0.jar!\com\lagodiuk\gp\symbolic\SymbolicRegressionIterationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */